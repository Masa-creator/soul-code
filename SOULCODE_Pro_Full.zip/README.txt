SOUL CODE — 完成版（静的）
- index.html / plans.html / paid.html / style.css / main.js / paid.js / favicon.ico / og-soulcode.png
紹介コード（無料フル解放・デモ）: SOULCODE.creator / SOULCODE.VIP / MASA2025
URLに ?referral=SOULCODE.creator を付与で自動入力。
生成時刻: 2025-08-21T16:20:22.334136Z
